<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

    //this method will show category
    public function index(){
        $this->load->view('admin/category/list');
    }
    //this method will show create category page
    public function create(){
        $this->load->view('admin/category/create');
    }
    //this method will edit category page
    public function edit(){
        
    }
    //this method will delete category page
    public function delete(){
        
    }

}